import java.util.Scanner;
import java.util.Collections;
import java.util.Arrays;


public class Part1 {
	public static void main(String []args){
		Scanner sc = new Scanner(System.in);
		String name = null;
		String cgpa=null;
		String reg_no=null;
		
		String [][]rec=new String[6][3];
		
		float[]c_gpa=new float[6];
		int[] reg_no_arr=new int[6];
		
		for (int i=0;i<6;i++){
			//This array will store individual fields
			String []indivRec=new String[3];
			System.out.println("Enter Name :"+i+":");
			name=sc.next();
			indivRec[0]=name;
			System.out.println("Enter Reg# :"+i+":");
			reg_no=sc.next();
			
			int temp_reg =Integer.parseInt(reg_no);
			reg_no_arr[i]=temp_reg;
			
			for(int j=0;j<i;j++){
				if(temp_reg==reg_no_arr[j]){
					
					while(temp_reg==reg_no_arr[j]){
						System.out.println("Reg no."+temp_reg+" already exists. Enter valid registration number\n");
						reg_no=sc.next();
						temp_reg =Integer.parseInt(reg_no);
						
					}
					
				}
				
			}
			
			indivRec[1]=reg_no;
			System.out.println("Enter cgpa :"+i+":");
			cgpa=sc.next();
			
			//checking for valid gpa.
			float val_cgpa =Float.parseFloat(cgpa);
			
			while(val_cgpa>4 || val_cgpa<0){
				System.out.println("Please Enter cpga in range of 0-4");
				cgpa=sc.next();
				val_cgpa =Float.parseFloat(cgpa);
			}
			//array for min/max cpga calculations
			c_gpa[i]=val_cgpa;
			
			
			indivRec[2]=cgpa;
			
			rec[i]=indivRec;
			
		}
		
	
		int arr_len=c_gpa.length;
		
		Arrays.sort(c_gpa);
		float min_gpa=c_gpa[0];
		float max_gpa=c_gpa[arr_len-1];
		//Printing the data of students
		for(int i=0;i<6;i++){
			for(int j=0;j<3;j++){
				System.out.println(rec[i][j]);
			}
			System.out.println("\n");
		}
		
		System.out.println("min cgpa= "+min_gpa+"\n");
		System.out.println("max cgpa= "+max_gpa+"\n");
		
		float avg_cpga =0 ;
		for(int i=0;i<arr_len;i++){
			avg_cpga +=c_gpa[i];
		}
		
		System.out.println("---------------------Min/Max and Avg cgpa---------------------\n");
		float arr_len_=(float)arr_len;
		
		float average= avg_cpga/arr_len_;
		
		
		System.out.println("average cgpa= "+average+"\n");
		
		System.out.println("---------------------Students having less than avg gpa---------------------\n");
		System.out.println("Students having less than average cgpa:\n");
		
		for(int i=0;i<6;i++){
			float temp_gpa= Float.parseFloat(rec[i][2]);
			if (temp_gpa<average){
				System.out.println(rec[i][0]);
			}
		}
		
		System.out.println("---------------------Finding Student Record---------------------\n");
		System.out.println("Enter Student name to find data.:\n");
		
		String stu_name=sc.next();
		
		float rank=0;
		
		for(int i=0; i<6;i++){
			if(stu_name.equalsIgnoreCase(rec[i][0])){
				System.out.println("Record Exists\n");
				System.out.println("The GPA of Student :"+rec[i][2]);
				rank=Float.parseFloat(rec[i][2]);
			}
				
		}
		
		for (int i=0;i<6;i++){
			if(c_gpa[i]==rank){
				System.out.println("\nThe rank of student :"+(6-i)+"/6\n");
			}
		}
		
	}
	
}
