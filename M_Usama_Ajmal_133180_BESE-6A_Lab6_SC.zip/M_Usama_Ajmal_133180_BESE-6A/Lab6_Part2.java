import java.util.Scanner;
import java.sql.*;

public class Part2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{
			int temp=1;
			do
			{
				System.out.println("**********MAIN MENU**********");
				System.out.println("1) View Record of Students\n2) Delete a Student\n3) View Specific Student Record\n");
				Scanner sc3=new Scanner(System.in);
				int choice=sc3.nextInt();
				
				Scanner sc= new Scanner(System.in);
				Connection myConn= (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/university_","root","usama123");
				
				switch(choice)
				{
				case 1:
					
					//TODO it may need to be modified   
					
					
					
					//**************DISPLAYING ALL DATABASE*********************
					
					System.out.println("**********Displaying the user record**********");
					Statement myStat= myConn.createStatement();			
					ResultSet myRs=myStat.executeQuery("select * from student");
						
					while(myRs.next())
					{
						System.out.println(myRs.getString("ID")+" "+myRs.getString("RegNo")+" "+myRs.getString("Name")+" "+myRs.getString("Class")+" "+myRs.getString("Section")+" "+myRs.getString("Contact")+" "+myRs.getString("Address"));
					}
					System.out.println("\n");
					break;
					
				case 2:	
					//**************DELETING A USER*********************
					System.out.println("**********DELETING A USER**********");
					
					System.out.println("Please enter the ID of student to delete");
					int Id=sc.nextInt();
					
					Statement delStat= myConn.createStatement();
					
					
					//PreparedStatement preparedStmt=null;
					PreparedStatement preparedStatement = null;
					
					String del_sql="DELETE FROM STUDENT WHERE ID =?";
					
					preparedStatement = myConn.prepareStatement(del_sql);
					preparedStatement.setInt(1, Id);
					int rowsAffected=preparedStatement.executeUpdate();
					
					System.out.println("Number of Rows affected : "+rowsAffected);
					System.out.println("Student Record Deleted Successfully !!");
					System.out.println("\n");
					break;
				case 3:
					//**************DISPLAYING ALL DATABASE*********************
					
					System.out.println("**********DISPLAYING A SINGLE USER RECORD**********");
					
					System.out.println("Enter the name of student:");
					Scanner sc2=new Scanner(System.in);
					String Name_=sc2.nextLine();
					Statement myStat2= myConn.createStatement();
					PreparedStatement preparedStatement2 = null;
					
					String find_sql="SELECT * FROM STUDENT WHERE Name =?";
					
					preparedStatement2 = myConn.prepareStatement(find_sql);
					preparedStatement2.setString(1, Name_);
					ResultSet myRs2=preparedStatement2.executeQuery();
					if(myRs2.next()){
					System.out.println(myRs2.getString("ID")+" "+myRs2.getString("RegNo")+" "+myRs2.getString("Name")+" "+myRs2.getString("Class")+" "+myRs2.getString("Section")+" "+myRs2.getString("Contact")+" "+myRs2.getString("Address"));
					}
					else
						System.out.println("Record does not exist. Make sure you are entering the correct name !!\n");
					
					break;
					
					default:
						System.out.println("Wrong Choice of Input");
						break;
				}
				System.out.println("To perform another operation enter '1' or press '2' to exit");
				Scanner sc4=new Scanner(System.in);
				temp=sc4.nextInt();
			}while(temp ==1);
		}
		
		catch(Exception exception)
		{
			exception.printStackTrace();
		}

	}

}
